INT8U  OSTaskCreateAperiodic(void  (*function)(void),
                            OS_STK* ptos,
                            INT8U   prio);
