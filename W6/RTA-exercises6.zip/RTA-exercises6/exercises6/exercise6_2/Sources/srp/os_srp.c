#include <ucos_ii.h>

//Resource  OSSRPSystemCeiling[MAX_RESOURCES];                       /* SRP system ceiling                              */
INT8U     OSSRPResourceCounter;
Resource* OSSRPTopOfStack;
Resource* OSSRPEmpty;
