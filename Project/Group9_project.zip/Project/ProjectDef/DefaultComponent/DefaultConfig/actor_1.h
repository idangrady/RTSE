/*********************************************************************
	Rhapsody	: 9.0 
	Login		: gebruiker
	Component	: DefaultComponent 
	Configuration 	: DefaultConfig
	Model Element	: actor_1
//!	Generated Date	: Sun, 12, Feb 2023  
	File Path	: DefaultComponent\DefaultConfig\actor_1.h
*********************************************************************/

#ifndef actor_1_H
#define actor_1_H

//## auto_generated
#include <oxf.h>
//## auto_generated
#include <aom.h>
//## auto_generated
#include "SystemContext.h"
//## package SystemContext

//## actor actor_1
class actor_1 {
    ////    Friends    ////
    
public :

#ifdef _OMINSTRUMENT
    friend class OMAnimatedactor_1;
#endif // _OMINSTRUMENT

    ////    Constructors and destructors    ////
    
    //## auto_generated
    actor_1(void);
    
    //## auto_generated
    ~actor_1(void);
};

#ifdef _OMINSTRUMENT
//#[ ignore
class OMAnimatedactor_1 : virtual public AOMInstance {
    DECLARE_META(actor_1, OMAnimatedactor_1)
};
//#]
#endif // _OMINSTRUMENT

#endif
/*********************************************************************
	File Path	: DefaultComponent\DefaultConfig\actor_1.h
*********************************************************************/
